﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SchoolManagementSystemOOP2.teachermodules
{
    public partial class ViewStudents : Form
    {
        private DataAccess Da { set; get; }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-A046G8V;Initial Catalog=SchoolManagementSystem;Persist Security Info=True;User ID=sa;Password=ouslukush");
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        public SqlCommand cmd;
        public ViewStudents()
        {
            Da = new DataAccess();
            InitializeComponent();
            DisplayData();
            classCombobox();
            cmd = new SqlCommand();
            Rda = new SqlDataAdapter();

        }
        public void classCombobox()
        {
            //cmbClass.Items.Clear();

            string sql = "select * from classes ";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string clname = rd.GetString(1);
                    cmbClass.Items.Add(clname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        private void ViewStudents_Load(object sender, EventArgs e)
        {

        }
        public void DisplayData()
        {
            DataSet ds = Da.ExecuteQuery("select * from student");
            this.dgvStudent.AutoGenerateColumns = false;
            this.dgvStudent.DataSource = ds.Tables[0];


        }

        private void cmbClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("select * from student where class = '" + this.cmbClass.Text + "'");
            this.dgvStudent.AutoGenerateColumns = false;
            this.dgvStudent.DataSource = ds.Tables[0];
        }
    }
}
