﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchoolManagementSystemOOP2.Service;
using System.Data.SqlClient;

namespace SchoolManagementSystemOOP2.teachermodules
{

    public partial class MakeNotice : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-A046G8V;Initial Catalog=SchoolManagementSystem;Persist Security Info=True;User ID=sa;Password=ouslukush");
        private DataAccess Da { set; get; }
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        SqlCommand cmd;
        string autoId;
        public MakeNotice()
        {
            InitializeComponent();
            Da = new DataAccess();
            classCombobox();
            DisplayData();
            GenerateID();
            SubjectCombobox();
        }
        public void GenerateID()
        {


            
            string query = "select notice_id from notice order by notice_id Desc";
            con.Open();
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                autoId = id.ToString("000");
                con.Close();
            }
            else if (Convert.IsDBNull(dr))
            {
                autoId = ("001");
            }
            else
            {
                autoId = ("001");
            }
            con.Close();
            lblId.Text = autoId.ToString();
        }
        public void classCombobox()
        {
            // cmbClass.Items.Clear();

            string sql = "select * from classes ";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string cname = rd.GetString(1);
                    cmbClass.Items.Add(cname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        public void SubjectCombobox()
        {
            cmbSubject.Items.Clear();

            string sql = "select * from subject";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string sname = rd.GetString(2);
                    cmbSubject.Items.Add(sname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        public void DisplayData()
        {
            DataSet ds = Da.ExecuteQuery("select * from notice");
            this.dgv.AutoGenerateColumns = false;
            this.dgv.DataSource = ds.Tables[0];
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("insert into notice values('" + this.lblId.Text + "','" + this.dtpDate.Text + "', '" + this.txtTitle.Text + "','" + this.txtDetails.Text + "','" + global.UserName + "','" + this.cmbClass.Text + "')");
            MessageBox.Show("Notice Published");
        }

        private void MakeNotice_Load(object sender, EventArgs e)
        {

        }

        private void metroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRow = e.RowIndex;
            DataGridViewRow row = dgv.Rows[selectedRow];
            //lblId.Text = row.Cells[0].Value.ToString();
            dtpDate.Text = row.Cells[0].Value.ToString();
            cmbSubject.Text = row.Cells[1].Value.ToString();
            txtTitle.Text = row.Cells[2].Value.ToString();
            txtDetails.Text = row.Cells[3].Value.ToString();
        }
    }
}
