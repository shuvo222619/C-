﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchoolManagementSystemOOP2.Service;
using System.Data.SqlClient;

namespace SchoolManagementSystemOOP2.teachermodules
{
    public partial class Make_Result : Form
    {
        DataAccess Da { set; get; }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-A046G8V;Initial Catalog=SchoolManagementSystem;Persist Security Info=True;User ID=sa;Password=ouslukush");
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        SqlCommand cmd;
        string proid;
        public Make_Result()
        {
            InitializeComponent();
            Da = new DataAccess();
            DataSet ds;
            DisplayData();
            SubjectCombobox();
            GenerateID();
            GradedStudents();
        }
        public void GradedStudents()
        {
            DataSet ds = Da.ExecuteQuery("select * from results where teacher='"+global.UserName+"'");
             this.dgvGraded.AutoGenerateColumns = false;
            this.dgvGraded.DataSource = ds.Tables[0];

        }
        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }
        public void SubjectCombobox()
        {
            cmbSubject.Items.Clear();

            string sql = "select * from subject";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string sname = rd.GetString(2);
                    cmbSubject.Items.Add(sname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        public void DisplayData()
        {
            DataSet ds = Da.ExecuteQuery("select * from student");
            // this.dgvAdmins.AutoGenerateColumns = false;
            this.dgv.DataSource = ds.Tables[0];

        }
        public void GenerateID()
        {



            string query = "select result_id from results order by result_id Desc";
            con.Open();
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                proid = id.ToString("000");
            }
            else if (Convert.IsDBNull(dr))
            {
                proid = ("001");
            }
            else
            {
                proid = ("001");
            }
            con.Close();
            rid.Text = proid.ToString();
        }
        private void Make_Result_Load(object sender, EventArgs e)
        {
            lblTeacher.Text = global.UserName;
        }
        private void PopulateGridView(string sql)
        {
            var ds = Da.ExecuteQuery(sql);
            this.dgv.AutoGenerateColumns = false;
            this.dgv.DataSource = ds.Tables[0];
        }
        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRow = e.RowIndex;
            DataGridViewRow row = dgv.Rows[selectedRow];
            lblName.Text = row.Cells[4].Value.ToString();
            lblId.Text = row.Cells[0].Value.ToString();
            lblClass.Text = row.Cells[13].Value.ToString();
            lblSection.Text = row.Cells[14].Value.ToString();
            
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("insert into results values('" + this.rid.Text + "','" + this.lblId.Text + "','" + this.lblName.Text + "', '" + this.cmbSubject.Text + "','" + this.lblClass.Text + "','" + this.lblSection.Text + "','" + this.txtMarks.Text + "','" + this.lblTeacher.Text + "')");
            MessageBox.Show("Result Assigned");
            GenerateID();
            GradedStudents();
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            string query = "select * from student where username like  '" + this.txtSearch.Text + "%' ";
            this.PopulateGridView(query);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dgvGraded_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRow = e.RowIndex;
            DataGridViewRow row = dgvGraded.Rows[selectedRow];
            lblId.Text = row.Cells[0].Value.ToString();
            lblName.Text = row.Cells[1].Value.ToString();
            lblSection.Text = row.Cells[4].Value.ToString();
            lblClass.Text = row.Cells[3].Value.ToString();
            cmbSubject.Text = row.Cells[2].Value.ToString();
           // lblTeacher.Text = row.Cells[3].Value.ToString();
            txtMarks.Text = row.Cells[5].Value.ToString();
            
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            string query = "update results SET marks = '" + this.txtMarks.Text + "' where student_id = '" + this.lblId.Text + "'";

            int rowCount = this.Da.ExecuteUpdateQuery(query);
            if (rowCount == 1)
            {
                MessageBox.Show("updated successfully");
            }
            else
            {
                MessageBox.Show("failed");
            }

            DisplayData();
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("delete from results where student_id = '" + lblId.Text + "' ");
            MessageBox.Show("Deleted");
            DisplayData();
        }
    }
}
