﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchoolManagementSystemOOP2.Service;

namespace SchoolManagementSystemOOP2.student
{
    public partial class CheckResult : Form
    {
        DataAccess Da { set; get; }
        public CheckResult()
        {

            InitializeComponent();
            Da = new DataAccess();
            DisplayData();
        }
        public void DisplayData()
        {
            DataSet ds = Da.ExecuteQuery("select * from results where student_name='"+global.UserName+"'");
             this.dgv.AutoGenerateColumns = false;
            this.dgv.DataSource = ds.Tables[0];

        }

        private void CheckResult_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
