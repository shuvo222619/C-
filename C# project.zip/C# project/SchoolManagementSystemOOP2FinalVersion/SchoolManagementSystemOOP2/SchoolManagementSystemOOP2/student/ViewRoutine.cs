﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SchoolManagementSystemOOP2.Service;

namespace SchoolManagementSystemOOP2.student
{
    public partial class ViewRoutine : Form
    {
        private DataAccess Da { set; get; }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-A046G8V;Initial Catalog=SchoolManagementSystem;Persist Security Info=True;User ID=sa;Password=ouslukush");
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        SqlCommand cmd;
        public ViewRoutine()
        {
            cmd = new SqlCommand();
            Da = new DataAccess();
            InitializeComponent();
            DisplayData();
            classCombobox();
        }
        public void classCombobox()
        {
            // cmbClass.Items.Clear();

            string sql = "select * from student where username='"+global.UserName+"' ";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string cname = rd.GetString(13);
                    cmbClass.Items.Add(cname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        public void DisplayData()
        {
            DataSet ds = Da.ExecuteQuery("select * from classroutine where class = '"+this.cmbClass.Text+"'");
            // this.dgvAdmins.AutoGenerateColumns = false;
            this.dgvRoutine.DataSource = ds.Tables[0];
            
        }

        private void bunifuCustomDataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dgvRoutine_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmbClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplayData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ViewRoutine_Load(object sender, EventArgs e)
        {

        }

        private void lblClass_Click(object sender, EventArgs e)
        {

        }
    }
}
