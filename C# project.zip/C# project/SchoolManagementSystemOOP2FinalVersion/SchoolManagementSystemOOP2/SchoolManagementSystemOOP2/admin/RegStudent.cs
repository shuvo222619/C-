﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;
    

namespace SchoolManagementSystemOOP2
{
    public partial class RegStudent : Form

    {


        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-A046G8V;Initial Catalog=SchoolManagementSystem;Persist Security Info=True;User ID=sa;Password=ouslukush");
        private DataAccess Da {set; get;}
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        SqlCommand cmd;

      
        public RegStudent()
        {
           
            InitializeComponent();
            this.Da = new DataAccess();
            this.Rda = new SqlDataAdapter();
            classCombobox();
            SectionCombobox();
            
           GenerateID();

        }


        public void GenerateID()
        {
            try
            {

                string sql = "select MAX(student_id) from student";
                cmd = new SqlCommand(sql, con);
                con.Open();
                var maxid = cmd.ExecuteScalar() as string;

                if (maxid == null)
                {
                    txtStuId.Text = "S-000001";

                }
                else
                {
                    int intval = int.Parse(maxid.Substring(2, 6));
                    intval++;
                    txtStuId.Text = string.Format("S-{0:000000}", intval);

                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox2_OnValueChanged(object sender, EventArgs e)
        {

        }
   
        private void bunifuMaterialTextbox3_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox4_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox6_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox5_OnValueChanged(object sender, EventArgs e)
        {

        }
        public void classCombobox()
        {
            // cmbClass.Items.Clear();

            string sql = "select * from classes ";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string cname = rd.GetString(1);
                    cmbClass.Items.Add(cname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        public void SectionCombobox()
        {
            //cmbClass.Items.Clear();

            string sql = "select * from section ";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string secname = rd.GetString(1);
                    cmbSection.Items.Add(secname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        private void RegStudent_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            
        }

       

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

          if (txtFirstName.Text == "")
            {
                MessageBox.Show("Please Enter First Name");
            }
            else if (txtLastName.Text == "")
            {
                MessageBox.Show("Please Enter Last Name");
            }
            else if (txtEmail.Text == "")
            {
                MessageBox.Show("Please Enter Email");
            }
            else if (txtUserName.Text == "")
            {
                MessageBox.Show("Please Enter UserName");
            }
            else if (txtFatherName.Text == "")
            {
                MessageBox.Show("Please Enter Father Name");
            }
            else if (txtMotherName.Text == "")
            {
                MessageBox.Show("Please Enter Mother Name");
            }
            else if (txtPhoneNumber.Text == "")
            {
                MessageBox.Show("Please Enter Phone Number");
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Please Enter Password");
            }
            else if (txtPassword.Text.Equals(txtConfirmPassword.Text)==false )
            {
                MessageBox.Show("Password does not match");
            }


         
            else {

                DataSet ds = Da.ExecuteQuery("select username from student where username='"+this.txtUserName.Text+"' ");
                DataTable dt = new DataTable();
                // dt = new DataTable();
                int i = ds.Tables[0].Rows.Count;
                
                    if (i > 0)
                    {
                        MessageBox.Show("username already exist");

                    }


                    else
                    {

                        ds = Da.ExecuteQuery("insert into student values('" + this.txtStuId.Text + "','" + this.txtFirstName.Text + "', '" + this.txtLastName.Text + "' , '" + this.txtEmail.Text + "','" + this.txtUserName.Text + "','" + this.cmbGender.Text + "','" + this.dtpDob.Text + "','" + this.txtFatherName.Text + "','" + this.txtMotherName.Text + "','" + this.txtConfirmPassword.Text + "','" + this.cmbStatus.Text + "','" + this.dtpDor.Text + "','" + this.txtPhoneNumber.Text + "','" + this.cmbClass.Text + "','" + this.cmbSection.Text + "','" + pictureBox.Image + "')");

                        ds = Da.ExecuteQuery("insert into users values( '" + this.txtUserName.Text + "','" + this.txtConfirmPassword.Text + "','" + this.student.Text + "' )");
                    GenerateID();
                    MessageBox.Show("Student Registered");
                }
                
            }

        }

        public void autoIdValue()
        {
           // var dt = DataAccess.
        }





        private void btnUp_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp; *.png)|*.jpg; *.jpeg; *.gif; *.bmp;*.png";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                pictureBox.Image = new Bitmap(open.FileName);
                // image file path  
                // textBox1.Text = open.FileName;
            }
        }

        private void btnClr_Click(object sender, EventArgs e)
        {
            pictureBox.Image = null;
        }

        private void bunifuMaterialTextbox23_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox21_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox22_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox24_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox20_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox19_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox17_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox18_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("delete from student where student_id = '" + txtStuId.Text + "' ");
            MessageBox.Show("Deleted");
            //DisplayData();
            GenerateID();
        }
    }
}
