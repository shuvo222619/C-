﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SchoolManagementSystemOOP2.admin
{
    public partial class ClassSchedule : Form
    {
       
        private DataAccess Da { set; get; }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-A046G8V;Initial Catalog=SchoolManagementSystem;Persist Security Info=True;User ID=sa;Password=ouslukush");
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        SqlCommand cmd;
        int selectedRow;
        string autoId;
        public ClassSchedule()
        {
            InitializeComponent();
            Da = new DataAccess();
            this.Da = new DataAccess();

            this.Rda = new SqlDataAdapter();
            cmd = new SqlCommand();
            GenerateID();
            DisplayData();
            classCombobox();
            SubjectCombobox();
            SectionCombobox();
           
        }
        public void classCombobox()
        {
           // cmbClass.Items.Clear();

            string sql = "select * from classes ";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string cname = rd.GetString(1);
                    cmbc.Items.Add(cname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        public void SectionCombobox()
        {
            //cmbClass.Items.Clear();

            string sql = "select * from section ";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string secname = rd.GetString(1);
                    cmbSection.Items.Add(secname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        public void GenerateID()
        {



            string query = "select id from classroutine order by id Desc";
            con.Open();
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                autoId = id.ToString("000");
            }
            else if (Convert.IsDBNull(dr))
            {
                autoId = ("001");
            }
            else
            {
                autoId = ("001");
            }
            con.Close();
            txtRoutineId.Text = autoId.ToString();
        }
        public void SubjectCombobox()
        {
            cmbSubject.Items.Clear();

            string sql = "select * from subject";

            cmd = new SqlCommand(sql, con);
            SqlDataReader rd;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    string sname = rd.GetString(2);
                    cmbSubject.Items.Add(sname);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();
        }
        public void DisplayData()
        {
            DataSet ds = Da.ExecuteQuery("select * from classroutine");
            // this.dgvAdmins.AutoGenerateColumns = false;
            this.dgvRoutine.DataSource = ds.Tables[0];
        }
       



        private void metroDateTime1_ValueChanged(object sender, EventArgs e)
        {
            dtpStartTime.CustomFormat = "hh:mm";
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dtpEndTime.CustomFormat = "HH:mm";
        }

        private void ClassSchedule_Load(object sender, EventArgs e)
        {

        }
      

        private void btnAdd_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("select * from classroutine where period ='" + this.cmbPeriod.Text + "'and subject='" + this.cmbSubject.Text + "'and  class='" + this.cmbc.Text + "' ");
            DataTable dt = new DataTable();
            // dt = new DataTable();
            int i = ds.Tables[0].Rows.Count;


            if (i > 0)
            {
                MessageBox.Show("Clash Time");

            }
            else {
                ds = Da.ExecuteQuery("insert into classroutine values('" + this.txtRoutineId.Text + "','" + this.cmbPeriod.Text + "', '" + this.cmbSubject.Text + "','" + this.cmbc.Text + "','" + this.cmbSection.Text + "','" + this.dtpStartTime.Text + "','" + this.dtpEndTime.Text + "','" + this.cmbDay.Text + "')");
                MessageBox.Show("Routine Created");
                DisplayData();
                GenerateID();
            }
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("delete from classroutine where id = '" + txtRoutineId.Text + "' ");
            MessageBox.Show("Deleted");
            DisplayData();
            GenerateID();
        }

        private void dgvRoutine_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRow = e.RowIndex;
            DataGridViewRow row = dgvRoutine.Rows[selectedRow];
            txtRoutineId.Text = row.Cells[0].Value.ToString();
            cmbPeriod.Text = row.Cells[1].Value.ToString();
            cmbSubject.Text = row.Cells[2].Value.ToString();
            cmbc.Text = row.Cells[3].Value.ToString();
            cmbSection.Text = row.Cells[4].Value.ToString();
            dtpStartTime.Text = row.Cells[5].Value.ToString();
            dtpEndTime.Text = row.Cells[6].Value.ToString();
            cmbDay.Text = row.Cells[7].Value.ToString();
        }

        private void cmbSubject_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbc_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            SubjectCombobox();
        }
        private void PopulateGridView(string sql)
        {
            var ds = Da.ExecuteQuery(sql);
            this.dgvRoutine.AutoGenerateColumns = false;
            this.dgvRoutine.DataSource = ds.Tables[0];
        }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void metroTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            string query = "select * from classroutine where id like  '" + this.txtSearch.Text + "%' ";
            this.PopulateGridView(query);
        }
    }
    

      
    
}
