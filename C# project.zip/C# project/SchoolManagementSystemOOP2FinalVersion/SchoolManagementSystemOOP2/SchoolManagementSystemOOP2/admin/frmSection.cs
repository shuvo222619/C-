﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SchoolManagementSystemOOP2.admin
{
    public partial class frmSection : Form
    {


        private DataAccess Da { set; get; }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-A046G8V;Initial Catalog=SchoolManagementSystem;Persist Security Info=True;User ID=sa;Password=ouslukush");
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        SqlCommand cmd;
        string proid;
        public frmSection()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.Rda = new SqlDataAdapter();
            cmd = new SqlCommand();
            GenerateID();



        }
        public void GenerateID()
        {
            
           
            
            string query = "select section_id from section order by section_id Desc";
            con.Open();
            cmd = new SqlCommand(query, con);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                proid = id.ToString("000");
            }
            else if (Convert.IsDBNull(dr)) {
                proid = ("001");
            }
            else
            {
                proid = ("001");
            }
            con.Close();
            txtSectionId.Text = proid.ToString();
        }
      
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void PopulateGridView(string sql)
        {
            var ds = Da.ExecuteQuery(sql);
            this.dgvSection.AutoGenerateColumns = false;
            this.dgvSection.DataSource = ds.Tables[0];
        }
        private void frmSection_Load(object sender, EventArgs e)
        {
            DisplayData();

        }
        public void DisplayData()
        {
            DataSet ds = Da.ExecuteQuery("select * from section");
            // this.dgvAdmins.AutoGenerateColumns = false;
            this.dgvSection.DataSource = ds.Tables[0];
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("select name from section where name ='" + this.txtSectionName.Text + "' ");
            DataTable dt = new DataTable();
            // dt = new DataTable();
            int i = ds.Tables[0].Rows.Count;


             if (i > 0)
             {
                 MessageBox.Show("Section already exist");

             }


             else
             {

                ds = Da.ExecuteQuery("insert into section values('"+this.txtSectionId.Text+"','" + this.txtSectionName.Text + "', '" + this.cmbStatus.Text + "')");
                MessageBox.Show("Section Created");
                DisplayData();
                GenerateID();


             }
        }

        private void dgvSection_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRow = e.RowIndex;
            DataGridViewRow row = dgvSection.Rows[selectedRow];
            txtSectionId.Text = row.Cells[0].Value.ToString();
            txtSectionName.Text = row.Cells[1].Value.ToString();
            cmbStatus.Text = row.Cells[2].Value.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("delete from section where section_id = '" + txtSectionId.Text + "' ");
            MessageBox.Show("Deleted");
            DisplayData();
            GenerateID();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string query = "update section SET name = '"+this.txtSectionName.Text+"' , status = '"+this.cmbStatus.Text+"' where section_id = '"+this.txtSectionId.Text+"'";
            
            int rowCount = this.Da.ExecuteUpdateQuery(query);
            if (rowCount == 1)
            {
                MessageBox.Show("updated successfully");
            }
            else
            {
                MessageBox.Show("failed");
            }

            DisplayData();
            GenerateID();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            DisplayData();
            txtSectionId.Text = proid.ToString();
            txtSectionName.Text = "";
            cmbStatus.Text = "";
        }

        private void panel10_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            string query = "select * from section where section_id like  '" + this.txtSearch.Text + "%' ";
            this.PopulateGridView(query);
        }
    }
}
