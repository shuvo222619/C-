﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchoolManagementSystemOOP2.admin;

namespace SchoolManagementSystemOOP2.TeachingModule
{
    public partial class TeachingStaff : Form
    {
        DataAccess Da { set; get; }
        public TeachingStaff()
        {
            InitializeComponent();
            Da = new DataAccess();
            DisplayData();
        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {
            RegTeacher rt = new RegTeacher();
            rt.Visible = true;
        }
        public void DisplayData()
        {
            DataSet ds = Da.ExecuteQuery("select * from teacher");
            this.dgvTeacher.AutoGenerateColumns = false;
            this.dgvTeacher.DataSource = ds.Tables[0];


        }

        private void TeachingStaff_Load(object sender, EventArgs e)
        {

        }
        private void PopulateGridView(string sql)
        {
            var ds = Da.ExecuteQuery(sql);
            this.dgvTeacher.AutoGenerateColumns = false;
            this.dgvTeacher.DataSource = ds.Tables[0];
        }
        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            string query = "select * from teacher where username like  '" + this.txtSearch.Text + "%' ";
            this.PopulateGridView(query);
        }

        private void dgvTeacher_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            int selectedRow = e.RowIndex;
            DataGridViewRow row = dgvTeacher.Rows[selectedRow];
            ViewTeacherDetails v = new ViewTeacherDetails();

            v.txtTeacherId.Text = row.Cells[0].Value.ToString();
            v.txtFirstName.Text = row.Cells[1].Value.ToString();
            v.txtLastName.Text = row.Cells[2].Value.ToString();
            v.txtEmail.Text = row.Cells[4].Value.ToString();
            v.txtUserName.Text = row.Cells[3].Value.ToString();
            v.cmbGender.Text = row.Cells[5].Value.ToString();
            v.txtSalary.Text = row.Cells[6].Value.ToString();
            v.dtpDor.Text = row.Cells[7].Value.ToString();
            v.dtpDob.Text = row.Cells[8].Value.ToString();
           v.txtEducation.Text = row.Cells[9].Value.ToString();
            v.txtConfirmPassword.Text = row.Cells[10].Value.ToString();
            v.cmbStatus.Text = row.Cells[11].Value.ToString();
            v.txtPhoneNumber.Text = row.Cells[12].Value.ToString();


            v.Show();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            DisplayData();
        }
    }
}
