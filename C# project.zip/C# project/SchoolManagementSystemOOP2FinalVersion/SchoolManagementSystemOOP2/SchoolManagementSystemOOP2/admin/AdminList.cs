﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SchoolManagementSystemOOP2.admin
{
    public partial class AdminList : Form
    {
        private DataAccess Da { set; get; }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-A046G8V;Initial Catalog=SchoolManagementSystem;Persist Security Info=True;User ID=sa;Password=ouslukush");
        private SqlDataAdapter Rda { set; get; }
        SqlDataReader dr;
        SqlCommand cmd;
        public AdminList()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.Rda = new SqlDataAdapter();
            cmd = new SqlCommand();
            GenerateID();
            DisplayData();
        }
        public void GenerateID()
        {
            try
            {

                Da = new DataAccess();
               
                 string sql = "select MAX(admin_id) from admin";
               cmd = new SqlCommand(sql,con);
                 con.Open();
                 
                var maxid = cmd.ExecuteScalar() as string;


                if (maxid == null)
                {
                    txtAdminId.Text = "A-000001";

                }
                else
                {
                    int intval = int.Parse(maxid.Substring(2, 6));
                    intval++;
                    txtAdminId.Text = string.Format("A-{0:000000}", intval);

                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();


        }
        public void DisplayData()
        {

            DataSet ds = Da.ExecuteQuery("select * from admin");
            this.dgvAdmins.AutoGenerateColumns = false;
            this.dgvAdmins.DataSource = ds.Tables[0];
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
          
        }

        private void AdminList_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp; *.png)|*.jpg; *.jpeg; *.gif; *.bmp;*.png";
            if (open.ShowDialog() == DialogResult.OK)
            { 
                pictureBox.Image = new Bitmap(open.FileName);
               
            }
            }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            if (txtFullname.Text == "")
            {
                MessageBox.Show("Please Enter Full Name");
            }
            else if (txtUsername.Text == "")
            {
                MessageBox.Show("Please Enter Username");
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Please Enter Password");
            }


            else
            {

                DataSet ds = Da.ExecuteQuery("select username from admin where username='" + this.txtUsername.Text + "'");
                DataTable dt = new DataTable();
                // dt = new DataTable();
                int i = ds.Tables[0].Rows.Count;

                if (i > 0)
                {
                    MessageBox.Show("username already exist");

                }


                else
                {

                    ds = Da.ExecuteQuery("insert into admin values('" + this.txtAdminId.Text + "','" + this.txtFullname.Text + "', '" + this.txtUsername.Text + "' , '" + this.txtPassword.Text + "','" + this.dtpDor.Text + "','" + this.dtpDob.Text + "','" + pictureBox.Image + "')");

                    ds = Da.ExecuteQuery("insert into users values( '" + this.txtUsername.Text + "','" + this.txtPassword.Text + "','" + this.lblAdmin.Text + "' )");
                    MessageBox.Show("User Added");
                    GenerateID();
                    DisplayData();
                }
            
            }
        
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            DataSet ds = Da.ExecuteQuery("delete from admin where admin_id = '" + txtAdminId.Text + "' ");
            ds = Da.ExecuteQuery("delete from users username = '" + txtUsername.Text + "' ");
            MessageBox.Show("Deleted");
            DisplayData();
            GenerateID();
        }

        private void dgvAdmins_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRow = e.RowIndex;
            DataGridViewRow row = dgvAdmins.Rows[selectedRow];
            txtAdminId.Text = row.Cells[0].Value.ToString();
            txtFullname.Text = row.Cells[1].Value.ToString();
            txtUsername.Text = row.Cells[2].Value.ToString();
            txtPassword.Text = row.Cells[3].Value.ToString();
            dtpDor.Text = row.Cells[4].Value.ToString();
            dtpDob.Text = row.Cells[5].Value.ToString();
        }

        private void PopulateGridView(string sql)
        {
            var ds = Da.ExecuteQuery(sql);
            this.dgvAdmins.AutoGenerateColumns = false;
            this.dgvAdmins.DataSource = ds.Tables[0];
        }
        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            string query = "select * from admin where username like  '" + this.txtSearch.Text + "%' ";
            this.PopulateGridView(query);
        }
        private void txtSearch_Click(object sender, EventArgs e)
        {

        }

        private void txtSearch_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            string query = "select * from admin where username like  '" + this.txtSearch.Text + "%' ";
            this.PopulateGridView(query);
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void txtAdminId_Click(object sender, EventArgs e)
        {

        }

        private void txtFullname_Click(object sender, EventArgs e)
        {

        }

        private void metroButton2_Click(object sender, EventArgs e)
        {

        }
    }
}
