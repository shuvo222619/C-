﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchoolManagementSystemOOP2.ui;
using SchoolManagementSystemOOP2.Entities;
using SchoolManagementSystemOOP2.Repository;
using SchoolManagementSystemOOP2.Service;

using System.Data.SqlClient;

namespace SchoolManagementSystemOOP2.ui
{
    public partial class Login : Form
    {
        private DataAccess Da { set; get; }
        public string utype;
        LoginService login;
        public Login()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            login = new LoginService();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
           if (txtUsername.Text == "")
            {
                MessageBox.Show("Please Enter Username");
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Enter Password");
            }



            else
            {
                
                    int result = login.LoginValidation(txtUsername.Text, txtPassword.Text);
                    if (result == 1)
                    {
                      global.UserName = txtUsername.Text;
                      frmStudentDashboard sd = new frmStudentDashboard();
                       this.Hide();
                        sd.Show();

                    }
                    else if (result == 2)
                    {
                    DataTable dt = new DataTable();

                    global.UserName = txtUsername.Text;
                    AdminDashboard ad = new AdminDashboard();
                        this.Hide();
                        ad.Show();
                    }
                    else if(result == 3)
                {
                    global.UserName = txtUsername.Text;
                    TeacherDashboard td = new TeacherDashboard();
                    this.Hide();
                    td.Show();
                }
                else
                {
                    MessageBox.Show("invalid login attempt");

                }
               
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
