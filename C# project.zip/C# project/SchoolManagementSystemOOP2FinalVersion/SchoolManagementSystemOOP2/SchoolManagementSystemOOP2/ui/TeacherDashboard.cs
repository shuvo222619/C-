﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SchoolManagementSystemOOP2.teachermodules;
using SchoolManagementSystemOOP2.Service;

namespace SchoolManagementSystemOOP2.ui
{
    public partial class TeacherDashboard : Form
    {
        public TeacherDashboard()
        {
            InitializeComponent();
        }

        private void TeacherDashboard_Load(object sender, EventArgs e)
        {
            lblUsername.Text = global.UserName;
        }
        private void ShowForm(Form frm)
        {
            container.Controls.Clear();
            frm.TopLevel = false;
            container.Controls.Add(frm);
            frm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            frm.Dock = DockStyle.Fill;
            frm.Show();

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            MakeNotice mn = new MakeNotice();
            ShowForm(mn);
        }

        private void btnTeachingStaff_Click(object sender, EventArgs e)
        {
            Make_Result mr = new Make_Result();
            ShowForm(mr);
        }

        private void lblUsername_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuTileButton3_Click(object sender, EventArgs e)
        {
            Make_Result mr = new Make_Result();
            ShowForm(mr);
        }

        private void bunifuTileButton1_Click(object sender, EventArgs e)
        {
            MakeNotice mn = new MakeNotice();
            ShowForm(mn);
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            ViewStudents vs = new ViewStudents();
            ShowForm(vs);
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }

        private void bunifuTileButton4_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }
    }
}
